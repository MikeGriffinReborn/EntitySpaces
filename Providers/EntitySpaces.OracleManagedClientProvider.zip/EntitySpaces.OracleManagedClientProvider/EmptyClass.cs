namespace EntitySpaces.OracleManagedClientProvider
{
    class EmptyClass
    {
    }
}
